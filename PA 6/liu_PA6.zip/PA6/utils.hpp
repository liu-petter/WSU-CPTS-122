#pragma once

#include <iostream>
#include <fstream>
#include <string>
#include <cctype>	// tolower()

using std::cin;
using std::cout;
using std::endl;
using std::string;